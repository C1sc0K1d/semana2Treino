package com.ford.eng.weektwo.repository;

import com.ford.eng.weektwo.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
}