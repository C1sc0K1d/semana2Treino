package com.ford.eng.weektwo.response;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.eng.weektwo.dto.ClienteDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class ClienteResponse extends BaseBodyResponse<ClienteResponse.ClienteResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ClienteResponseResult{
        private ClienteDto cliente;
    }
}
