package com.ford.eng.weektwo.exception;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    public final ResponseEntity<Object> handelNotFound(NotFoundException exceptio){
        BaseBodyError error = BaseBodyError.builder()
                                .errorCode(HttpStatus.NOT_FOUND.toString())
                                .message(exceptio.getMessage()).build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                .body(BaseBodyResponse.error(error, BaseBodyResponse.class));
    }
}
