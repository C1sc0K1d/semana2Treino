package com.ford.eng.weektwo.response;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.eng.weektwo.dto.ServicoDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

public class ServicoListResponse extends BaseBodyResponse<ServicoListResponse.ServicoListResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ServicoListResponseResult{
        private List<ServicoDTO> servicos;
    }
}
