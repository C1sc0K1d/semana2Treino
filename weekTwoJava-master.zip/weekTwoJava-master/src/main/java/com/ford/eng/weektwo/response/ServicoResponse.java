package com.ford.eng.weektwo.response;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.eng.weektwo.dto.ServicoDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class ServicoResponse extends BaseBodyResponse<ServicoResponse.ServicoResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ServicoResponseResult {
        private ServicoDTO servico;
    }

}
