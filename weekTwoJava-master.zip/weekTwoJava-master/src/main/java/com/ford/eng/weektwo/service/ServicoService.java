package com.ford.eng.weektwo.service;

import com.ford.eng.weektwo.dto.ServicoDTO;
import com.ford.eng.weektwo.entity.Cliente;
import com.ford.eng.weektwo.entity.Servico;
import com.ford.eng.weektwo.mapper.ServicoMapper;
import com.ford.eng.weektwo.repository.ServicoRepository;
import com.ford.eng.weektwo.request.ServicoRequest;
import com.ford.eng.weektwo.response.ServicoListResponse;
import com.ford.eng.weektwo.response.ServicoResponse;
import com.ford.eng.weektwo.util.BigDecimalConverter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RequiredArgsConstructor
@Slf4j
@Service
public class ServicoService {

    private final ClienteService clienteService;
    private final ServicoRepository servicoRepository;
    private final BigDecimalConverter bigDecimalConverter;
    private final ServicoMapper servicoMapper;

    public Servico salvar(ServicoRequest dto){
        LocalDate data = LocalDate.parse(dto.getData(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        Integer idCliente = dto.getIdCliente();

        Cliente cliente = clienteService.getClientById(idCliente);

        Servico servico = new Servico();
        servico.setDescricao(dto.getDescricao());
        servico.setData(data);
        servico.setCliente(cliente);
        servico.setValor(bigDecimalConverter.converter(dto.getPreco()));

        return servicoRepository.save(servico);
    }

    public List<Servico> pesquisa(String nome, Integer mes){
        return servicoRepository.findByNomeClienteAndMes("%" + nome + "%", mes);
    }

    public ServicoResponse.ServicoResponseResult sendSingleResult(Servico servico){
        return this.servicoMapper.toSingleResult(servico);
    }

    public ServicoListResponse.ServicoListResponseResult sendListResult(List<Servico> servicos){
        return this.servicoMapper.toList(servicos);
    }
}
