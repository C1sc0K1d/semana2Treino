package com.ford.eng.weektwo.service;

import com.ford.eng.weektwo.entity.Cliente;
import com.ford.eng.weektwo.exception.NotFoundException;
import com.ford.eng.weektwo.mapper.ClienteMapper;
import com.ford.eng.weektwo.repository.ClienteRepository;

import com.ford.eng.weektwo.request.ClienteRequest;
import com.ford.eng.weektwo.response.ClienteListResponse;
import com.ford.eng.weektwo.response.ClienteResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Slf4j
@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final ClienteMapper clienteMapper;

    @Transactional
    public Cliente createCliente(@Valid ClienteRequest request) {
        Cliente clienteRequest = this.clienteRepository.save(this.clienteMapper.toCliente(request));
        return clienteRequest;
    }

    public List<Cliente> getClientes() {
        return this.clienteRepository.findAll();
    }

    public Cliente getClientById(Integer id) {

        return this.clienteRepository.findById(id)
                .orElseThrow(
                () -> new NotFoundException("Cliente de id " + id + " não encontrado")
                );
    }

    public void deleteCliente(Integer id){
        Optional<Cliente> cliente = this.clienteRepository.findById(id);
        if (cliente.isPresent()){
            this.clienteRepository.deleteById(id);
        }else{
            throw new NotFoundException("Cliente de id " + id + " não encontrado");
        }

    }

    public Cliente updateCliente(Integer id, ClienteRequest clienteAtualiza){
        return this.clienteRepository.findById(id).map(cliente -> {
            cliente.setNome(clienteAtualiza.getNome());
            cliente.setCpf((clienteAtualiza.getCpf()));
            return this.clienteRepository.save(cliente);
        }).orElseThrow(
                () -> new NotFoundException("Cliente de id " + id + " não encontrado") );
    }


    public ClienteResponse.ClienteResponseResult sendSingleResult(Cliente cliente){
        return this.clienteMapper.toSingleResult(cliente);
    }

    public ClienteListResponse.ClienteListResponseResult sendListResult(List<Cliente> clientes){
        return this.clienteMapper.toListResult(clientes);
    }


}
