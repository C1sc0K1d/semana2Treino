package com.ford.eng.weektwo;

import com.ford.cloudnative.annotations.EnableFordSecurityTools;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableFordSecurityTools
public class WeektwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeektwoApplication.class, args);
	}

}
