package com.ford.eng.weektwo.response;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.eng.weektwo.dto.ClienteDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

public class ClienteListResponse extends BaseBodyResponse<ClienteListResponse.ClienteListResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ClienteListResponseResult{
        private List<ClienteDto> clientes;
    }
}
