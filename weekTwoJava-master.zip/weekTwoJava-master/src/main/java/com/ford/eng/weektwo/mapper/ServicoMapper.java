package com.ford.eng.weektwo.mapper;

import com.ford.eng.weektwo.dto.ServicoDTO;
import com.ford.eng.weektwo.entity.Cliente;
import com.ford.eng.weektwo.entity.Servico;
import com.ford.eng.weektwo.request.ServicoRequest;
import com.ford.eng.weektwo.response.ServicoListResponse;
import com.ford.eng.weektwo.response.ServicoResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
public class ServicoMapper {

    private final ClienteMapper clienteMapper;

    public Servico toServico(@Valid Servico servico){
        return Servico.builder()
                .cliente(servico.getCliente())
                .descricao(servico.getDescricao())
                .valor(servico.getValor())
                .data(servico.getData())
                .build();
    }

    public ServicoDTO toDto(Servico servico){
        return ServicoDTO.builder()
                .cliente(clienteMapper.toDto(servico.getCliente()))
                .descricao(servico.getDescricao())
                .preco(servico.getValor().toString())
                .data(servico.getData().toString())
                .build();
    }

    public List<ServicoDTO> toListDto(List<Servico> servicos){
        return servicos.stream().map(this::toDto)
                .collect(Collectors.toList());
    }

    public ServicoResponse.ServicoResponseResult toSingleResult(Servico servico){
        return ServicoResponse.ServicoResponseResult.builder()
                .servico(this.toDto(servico)).build();
    }

    public ServicoListResponse.ServicoListResponseResult toList(List<Servico> servicos){
        return ServicoListResponse.ServicoListResponseResult.builder()
                .servicos(this.toListDto(servicos))
                .build();
    }

}