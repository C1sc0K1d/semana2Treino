package com.ford.eng.weektwo.controller;

import com.ford.eng.weektwo.dto.ServicoDTO;
import com.ford.eng.weektwo.entity.Cliente;
import com.ford.eng.weektwo.entity.Servico;
import com.ford.eng.weektwo.repository.ClienteRepository;
import com.ford.eng.weektwo.repository.ServicoRepository;

import com.ford.eng.weektwo.request.ServicoRequest;
import com.ford.eng.weektwo.response.ClienteResponse;
import com.ford.eng.weektwo.response.ServicoListResponse;
import com.ford.eng.weektwo.response.ServicoResponse;
import com.ford.eng.weektwo.service.ServicoService;
import com.ford.eng.weektwo.util.BigDecimalConverter;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;


@RestController
@RequestMapping("/api/servicos")
@RequiredArgsConstructor
public class ServicoController {

    private final ServicoService servicoService;

    @ApiOperation(value = "Cria serviço", notes = "Cria um novo serviço",
            response = ServicoResponse.ServicoResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "descricao", value = "Descrição do serviço", required = true, dataType = "string"),
            @ApiImplicitParam(name = "cliente", value = "id do cliente", required = true, dataType = "number"),
            @ApiImplicitParam(name = "valor", value = "valor do serviço", required = true, dataType = "BigDecimal")
    })
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<ServicoResponse> salvar(@RequestBody @Valid ServicoRequest dto){
        return ResponseEntity.ok(ServicoResponse
            .result(this.servicoService
                    .sendSingleResult(this.servicoService
                            .salvar(dto)), ServicoResponse.class));
    }
    @ApiOperation(value = "obter serviços filtrados", notes = "Tras os serviços filtrados pelo id do cliente e mes que foi solicitado o serviço",
            response = ServicoListResponse.ServicoListResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping
    public ResponseEntity<ServicoListResponse> pesquisa(
            @RequestParam(value = "nome", required = false, defaultValue = "") String nome,
            @RequestParam(value = "mes", required = false) Integer mes
    ){
     return ResponseEntity.ok(ServicoListResponse
             .result(this.servicoService
                .sendListResult(this.servicoService
                    .pesquisa(nome, mes)), ServicoListResponse.class));
    }
}
