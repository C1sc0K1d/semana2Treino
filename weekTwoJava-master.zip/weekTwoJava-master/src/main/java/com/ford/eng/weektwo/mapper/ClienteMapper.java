package com.ford.eng.weektwo.mapper;

import com.ford.eng.weektwo.dto.ClienteDto;
import com.ford.eng.weektwo.dto.ClienteInformationDto;
import com.ford.eng.weektwo.entity.Cliente;
import com.ford.eng.weektwo.request.ClienteRequest;
import com.ford.eng.weektwo.response.ClienteListResponse;
import com.ford.eng.weektwo.response.ClienteResponse;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
public class ClienteMapper {

    public Cliente toCliente(@Valid ClienteRequest cliente){
        return Cliente.builder()
                                .nome(cliente.getNome())
                                .cpf(cliente.getCpf())
                                .dataCadastro(cliente.getDataCadastro())
                                .build();

    }

    public ClienteDto toDto(Cliente cliente){
        return ClienteDto.builder()
                                .id(cliente.getId())
                                .cpf(cliente.getCpf())
                                .dataCadastro(cliente.getDataCadastro())
                                .nome(cliente.getNome()).build();
    }

    public ClienteInformationDto informationDto(Cliente cliente){
        return ClienteInformationDto.builder().id(cliente.getId()).build();
    }

    public List<ClienteInformationDto> toListInformationDto(List<Cliente> clientes){
        return clientes.stream().map(this::informationDto).collect(Collectors.toList());
    }

    public List<ClienteDto> toListDto(List<Cliente> clientes){
        return clientes.stream().map(this::toDto).collect(Collectors.toList());
    }

    public ClienteResponse.ClienteResponseResult toSingleResult(Cliente cliente){
        return ClienteResponse.ClienteResponseResult.builder().cliente(this.toDto(cliente)).build();
    }

    public ClienteListResponse.ClienteListResponseResult toListResult(List<Cliente> clientes){
        return ClienteListResponse.ClienteListResponseResult
                                                            .builder()
                                                            .clientes(this.toListDto(clientes))
                                                            .build();
    }
}
