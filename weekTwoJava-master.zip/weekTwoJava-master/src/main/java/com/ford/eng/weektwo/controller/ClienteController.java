package com.ford.eng.weektwo.controller;

import com.ford.eng.weektwo.repository.ClienteRepository;

import com.ford.eng.weektwo.request.ClienteRequest;
import com.ford.eng.weektwo.response.ClienteListResponse;
import com.ford.eng.weektwo.response.ClienteResponse;
import com.ford.eng.weektwo.service.ClienteService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Slf4j
@RequestMapping("/api/clientes")
@RequiredArgsConstructor
public class ClienteController {

    private final ClienteRepository repository;
    private final ClienteService clienteService;



    @ApiOperation(value = "obter todos clientes", notes = "Tras todos os clientes",
            response = ClienteResponse.ClienteResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping
    public ResponseEntity<ClienteListResponse> obterTodos(){
        return ResponseEntity.ok(ClienteListResponse
                .result(this.clienteService
                        .sendListResult(this.clienteService
                                .getClientes()), ClienteListResponse.class));

        //return repository.findAll();
    }
    @ApiOperation(value = "salvar cliente",
                    notes = "Salva um cliente novo",
                    response = ClienteListResponse.ClienteListResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "nome", value = "nome do cliente", required = true, dataType = "string"),
            @ApiImplicitParam(name = "cpf", value = "cpf do cliente", required = true, dataType = "string")
    })
    @PostMapping
    public ResponseEntity<ClienteResponse> salvar(@RequestBody @Valid ClienteRequest cliente){
        return ResponseEntity.ok(ClienteResponse
                .result(this.clienteService
                        .sendSingleResult(this.clienteService
                                .createCliente(cliente)),
                        ClienteResponse.class));
    }

    @ApiOperation(value = "achar clitente por Id", notes = "Tras clientes por id",
            response = ClienteResponse.ClienteResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @GetMapping("{id}")
    public ResponseEntity<ClienteResponse> acharPorId(@PathVariable Integer id){
        return ResponseEntity.ok(ClienteResponse
                .result(this.clienteService
                        .sendSingleResult(this.clienteService
                                .getClientById(id)),
                        ClienteResponse.class));

    }

    @ApiOperation(value = "deletar cliente", notes = "Apaga cliente pelo id",
            response = ClienteResponse.ClienteResponseResult.class)
    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @DeleteMapping("{id}")
    public void deletar(@PathVariable Integer id){
        this.clienteService.deleteCliente(id);
    }

    @ApiOperation(value = "atualizar cliente",
            notes = "Atualiza um cliente",
            response = ClienteResponse.ClienteResponseResult.class)

    @ApiResponses({
            @ApiResponse(code = 201, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 406, message = "Not Acceptable"),
            @ApiResponse(code = 500, message = "Internal server error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "id do cliente", required = true, dataType = "number"),
            @ApiImplicitParam(name = "nome", value = "nome do cliente", required = true, dataType = "string"),
            @ApiImplicitParam(name = "cpf", value = "cpf do cliente", required = true, dataType = "string")
    })
    @PutMapping("{id}")
    public void atualizar(@PathVariable Integer id, @RequestBody @Valid ClienteRequest clienteAtualizado){
        ResponseEntity.ok(ClienteResponse
                .result(this.clienteService
                        .sendSingleResult(this.clienteService
                                .updateCliente(id, clienteAtualizado)),
                        ClienteResponse.class ));
    }

}
