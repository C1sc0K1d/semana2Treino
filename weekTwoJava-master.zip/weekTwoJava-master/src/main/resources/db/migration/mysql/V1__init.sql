CREATE TABLE `cliente` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `nome` VARCHAR(155) NOT NULL,
    `cpf` VARCHAR(11) NOT NULL,
    `data_cadastro` DATE NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_UNIQUE` (`id` ASC)
) ENGINE = InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `servico` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `descricao` VARCHAR(255) NOT NULL,
    `id_cliente` INT NOT NULL,
    `valor` DECIMAL(15,2) NOT NULL,
    `data` DATE NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_unique` (`id` ASC),
    INDEX `id_cliente_fk_idx` (`id_cliente` ASC),
    CONSTRAINT `id_cliente_app_fk`
        FOREIGN KEY (`id_cliente`)
        REFERENCES `cliente` (`id`)
) ENGINE = InnoDB DEFAULT CHARSET=latin1;