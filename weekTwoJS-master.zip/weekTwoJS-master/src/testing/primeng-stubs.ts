//need to mock the primeng stuff we use in this part of the app
import {
	Component,
	Injectable,
	Input,
	Directive,
	AfterContentInit,
	ContentChildren,
	QueryList,
	TemplateRef,
	ChangeDetectorRef,
	forwardRef,
	OnInit,
	OnChanges
} from '@angular/core';
import {PrimeTemplate} from 'primeng/shared';
import {Confirmation} from 'primeng/api';
import {
	ControlValueAccessor,
	NG_VALUE_ACCESSOR
} from '@angular/forms';
import { Subject, Subscription } from 'rxjs';

@Component({
	selector: 'p-dropdown',
	template: '',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => MockDropDownComponent),
			multi: true
		}
	]
})
export class MockDropDownComponent implements ControlValueAccessor {
	_options: any[];
	@Input() get options(): any[] {
		return this._options;
	}

	set options(val: any[]) {
		//let opts = this.optionLabel ? ObjectUtils.generateSelectItems(val, this.optionLabel) : val;
		this._options = val;
		// this.optionsToDisplay = this._options;
		// this.updateSelectedOption(this.value);
		// this.optionsChanged = true;

		// if (this.filterValue && this.filterValue.length) {
		// 	this.activateFilter();
		// }
	}

	@Input() style: any;

	value: any;
	private _disabled: boolean;

	@Input() get disabled(): boolean {
		return this._disabled;
	}

	set disabled(_disabled: boolean) {
		//if(_disabled)
			//this.focused = false;

		this._disabled = _disabled;
		this.cd.detectChanges();
	}

	onModelChange = () => {};
	onModelTouched = () => {};

	constructor(private cd: ChangeDetectorRef) {}

	writeValue(value: any): void {
		// if (this.filter) {
		// 	this.resetFilter();
		// }

		this.value = value;
		//this.updateSelectedOption(value);
		//this.updateEditableLabel();
		//this.updateFilledState();
		this.cd.markForCheck();
	}

	registerOnChange(fn: () => void): void {
		this.onModelChange = fn;
	}

	registerOnTouched(fn: () => void): void {
		this.onModelTouched = fn;
	}

	setDisabledState(val: boolean): void {
		this.disabled = val;
	}
}

@Component({
	selector: 'p-growl',
	template: ''
})
export class MockGrowlComponent {
	@Input() value;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-confirmDialog',
	template: ''
})
export class MockConfirmDialogComponent {
	@Input() style;
}

@Component({
	selector: 'p-dialog',
	template: ''
})
export class MockDialogComponent {
	@Input() visible;
	@Input() header;
}

@Component({
	selector: 'p-footer',
	template: ''
})
export class MockFooterComponent {
}

@Component({
	selector: 'p-header',
	template: ''
})
export class MockHeaderComponent {
}

@Component({
	selector: 'p-panel',
	template: ''
})
export class MockPanelComponent {
}

//mock the table so we can test its templates. This mock is set up to do the following:
// - minimally compile the p-table component
// - create an html table with the given thead and tbody templates
// - pass the given columns through to the thead and tbody
// - pass the first item of the dataset through to the tbody for display
@Component({
	selector: 'p-table',
	template: `
		<div *ngIf="captionTemplate" class="ui-table-caption ui-widget-header">
			<ng-container *ngTemplateOutlet="captionTemplate"></ng-container>
		</div>
		<p-paginator [rows]="rows" [first]="first" [totalRecords]="totalRecords"
					 *ngIf="paginator && (paginatorPosition === 'top' || paginatorPosition =='both')"
					 [templateLeft]="paginatorLeftTemplate" [templateRight]="paginatorRightTemplate"></p-paginator>
		<table>
			<thead class="ui-table-thead">
				<ng-container *ngTemplateOutlet="headerTemplate; context: {$implicit: columns}"></ng-container>
			</thead>
			<tbody class="ui-table-tbody">
				<ng-container *ngTemplateOutlet="bodyTemplate; context: {$implicit: rowData, columns: columns}"></ng-container>
			</tbody>
		</table>
		<p-paginator [rows]="rows" [first]="first" [totalRecords]="totalRecords"
					 *ngIf="paginator && (paginatorPosition === 'bottom' || paginatorPosition =='both')"
					 [templateLeft]="paginatorLeftTemplate" [templateRight]="paginatorRightTemplate"></p-paginator>
	`
})
export class MockTableComponent implements AfterContentInit {
	@ContentChildren(PrimeTemplate) templates: QueryList<PrimeTemplate>;
	@Input() value;
	@Input() responsive;
	@Input() rows;
	@Input() pageLinks;
	@Input() paginator;
	@Input() selection;
	@Input() customSort;
	@Input() columns;
	@Input() paginatorPosition;
	@Input() rowsPerPageOptions;
	@Input() lazy;
	@Input() loading;
	@Input() loadingIcon;
	@Input() showLoader;
	@Input() resetPageOnSort;
	@Input() selectionMode;
	rowData;
	first = 0;

	captionTemplate: TemplateRef<any>;
	headerTemplate: TemplateRef<any>;
	bodyTemplate: TemplateRef<any>;
	paginatorLeftTemplate: TemplateRef<any>;
	paginatorRightTemplate: TemplateRef<any>;

	ngAfterContentInit() {
		//explicitly pick off the first row and give it to the body template
		this.rowData = this.value[0];

		this.templates.forEach((item) => {
			switch (item.getType()) {
				case 'caption':
					this.captionTemplate = item.template;
					break;

				case 'header':
					this.headerTemplate = item.template;
					break;

				case 'body':
					this.bodyTemplate = item.template;
					break;

				case 'paginatorleft':
					this.paginatorLeftTemplate = item.template;
					break;

				case 'paginatorright':
					this.paginatorRightTemplate = item.template;
					break;
			}
		});
	}
}

@Component({
	selector: 'p-paginator',
	template: `
        <div>
            <div class="ui-paginator-left-content" *ngIf="templateLeft">
                <ng-container *ngTemplateOutlet="templateLeft; context: {$implicit: paginatorState}"></ng-container>
            </div>
            <div class="ui-paginator-right-content" *ngIf="templateRight">
                <ng-container *ngTemplateOutlet="templateRight; context: {$implicit: paginatorState}"></ng-container>
            </div>
        </div>
    `
})
export class MockPaginatorComponent implements OnInit {
	@Input() rows;
	@Input() first;
	@Input() totalRecords;
	@Input() pageLinks;
	@Input() templateLeft;
	@Input() templateRight;

	paginatorState: any;

	ngOnInit(): void {
		this.paginatorState = {
			page: this.getPage(),
			pageCount: this.getPageCount(),
			rows: this.rows,
			first: this.first,
			totalRecords: this.totalRecords
		};
	}

	getPage(): number {
		return Math.floor(this.first / this.rows);
	}
	getPageCount() {
		return Math.ceil(this.totalRecords / this.rows) || 1;
	}
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-tableHeaderCheckbox',
	template: ''
})
export class MockTableHeaderCheckboxComponent {

}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-tableCheckbox',
	template: ''
})
export class MockTableCheckboxComponent {
	@Input() value;
}

@Component({
	selector: 'p-button',
	template: ''
})
export class MockButtonComponent {
	@Input() disabled;
	@Input() icon;
	@Input() label;
	@Input() type;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: '[pButton]',
	template: '{{label}}'
})
//disable as this needs to match the PrimeNG surface api
//tslint:disable-next-line
export class MockButtonAttributeDirective {
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	@Input('label') label;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-dataTable',
	template: ''
})
export class MockDataTableComponent {
	@Input() value;
	@Input() responsive;
	@Input() rows;
	@Input() pageLinks;
	@Input() paginator;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: '[pSortableColumn]',
	template: ''
})
//disable as this needs to match the PrimeNG surface api
//tslint:disable-next-line
export class MockSortableColumnDirective {
	@Input() pSortableColumn;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-sortIcon',
	template: ''
})
export class MockSortIconComponent  {
	@Input() field;
}

@Component({
	selector: 'p-column',
	template: ''
})
export class MockColumnComponent {
}

@Injectable()
export class MockConfirmationService {
	confirm = jasmine.createSpy('confirm').and.callFake((obj: Confirmation) => {
		obj.accept();
	});
}

@Injectable()
export class MockMessageService {
	add = jasmine.createSpy('add');
	clear() {}
}

@Component({
	selector: 'p-menubar',
	template: ''
})
export class MockMenubarComponent {
	@Input() model;
}

@Component({
	//disable as this needs to match the PrimeNG surface api
	//tslint:disable-next-line
	selector: 'p-splitButton',
	template: ''
})
export class MockSplitButtonComponent {
	@Input() model;
}

@Component({
	selector: 'p-steps',
	template: ''
})
export class MockStepsComponent {
	@Input() model;
	@Input() activeIndex;
}

@Component({
	selector: 'p-autoComplete',
	template: '',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => MockAutoCompleteComponent),
			multi: true
		}
	]
})
export class MockAutoCompleteComponent implements ControlValueAccessor {
	@Input() suggestions: any[];
	@Input() style: any;
	@Input() minLength: any;

	value: any;

	onModelChange = () => {};
	onModelTouched = () => {};

	constructor(private cd: ChangeDetectorRef) {}

	writeValue(value: any): void {
		this.value = value;
		this.cd.markForCheck();
	}

	registerOnChange(fn: () => void): void {
		this.onModelChange = fn;
	}

	registerOnTouched(fn: () => void): void {
		this.onModelTouched = fn;
	}

}

@Component({
	selector: 'p-calendar',
	template: '',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => MockCalendarComponent),
			multi: true
		}
	]
})
export class MockCalendarComponent implements ControlValueAccessor {
	@Input() readonlyInput: any;
	@Input() style: any;
	@Input() minDate: any;
	@Input() maxDate: any;
	@Input() showIcon: any;

	value: any;

	onModelChange = () => {};
	onModelTouched = () => {};

	constructor(private cd: ChangeDetectorRef) {}

	writeValue(value: any): void {
		this.value = value;
		this.cd.markForCheck();
	}

	registerOnChange(fn: () => void): void {
		this.onModelChange = fn;
	}

	registerOnTouched(fn: () => void): void {
		this.onModelTouched = fn;
	}

}
