/*
 Copyright 2017 Google Inc. All Rights Reserved.
 Use of this source code is governed by an MIT-style license that
 can be found in the LICENSE file at http://angular.io/license
 */

import {Event} from '@angular/router/esm5/src/events';
import {
	Component,
	Directive,
	ElementRef,
	HostListener,
	Injectable,
	Input,
	OnInit
} from '@angular/core';
import {NavigationExtras, UrlTree} from '@angular/router';
// Only implements params and part of snapshot.params
import {
	BehaviorSubject,
	Observable
} from 'rxjs';

export {
	ActivatedRoute,
	Router,
	RouterLink,
	RouterOutlet
} from '@angular/router';

@Directive({
	selector: '[routerLink]'

})
export class RouterLinkStubDirective implements OnInit {
	//disable as this needs to match the surface api
	//tslint:disable-next-line
	@Input('routerLink') linkParams: any;
	@Input() state?: any;

	//navigatedTo: any = null;
	constructor(private el: ElementRef) {}
	ngOnInit() {
		this.el.nativeElement.setAttribute('href', this.linkParams);
	}
}

@Component({
	selector: 'router-outlet',
	template: ''
})
//disable as this needs to match the surface api
//tslint:disable-next-line
export class RouterOutletStubDirective {
	@HostListener('activate') onClick() {

	}
}

@Injectable()
export class RouterStub {
	events: Observable<Event>;

	navigate(commands: any[], extras?: NavigationExtras) {
	}

	navigateByUrl(url: string | UrlTree, extras?: NavigationExtras) { }

	getCurrentNavigation() {
		return null;
	}
}

@Injectable()
export class ActivatedRouteStub {

	// ActivatedRoute.params is Observable
	private paramsSubject = new BehaviorSubject(this.testParams);
	params = this.paramsSubject.asObservable();

	private queryParamsSubject = new BehaviorSubject(this.testQueryParams);
	queryParams = this.queryParamsSubject.asObservable();

	// ActivatedRoute.data is Observable
	private dataSubject = new BehaviorSubject(this.testData);
	data = this.dataSubject.asObservable();

	// url mapping
	private _url: [{path: string}];
	get url() { return this._url; }
	set url(url: [{path: string}]) {
		this._url = url;
	}

	// Test parameters
	private _testParams: {};
	get testParams() { return this._testParams; }
	set testParams(params: {}) {
		this._testParams = params;
		this.paramsSubject.next(params);
	}

	// Test query parameters
	private _testQueryParams: {};
	get testQueryParams() { return this._testQueryParams; }
	set testQueryParams(queryParams: {}) {
		this._testQueryParams = queryParams;
		this.queryParamsSubject.next(queryParams);
	}

	// Test data
	private _testData: {};
	get testData() { return this._testData; }
	set testData(data: {}) {
		this._testData = data;
		this.dataSubject.next(data);
	}

	// ActivatedRoute.snapshot.params
	get snapshot() {
		return {
			params: this.testParams,
			queryParams: this.testQueryParams,
			data: this.testData
		};
	}
}

export interface UrlSegmentStub {
	path: string;
}

@Injectable()
export class ActivatedRouteSnapshotStub {

	// url mapping
	private _url: UrlSegmentStub[] = [];
	get url() { return this._url; }
	set url(url: UrlSegmentStub[]) {
		this._url = url;
	}

	// Test parameters
	private _params = {};
	get params() { return this._params; }
	set params(params: {}) {
		this._params = params;
	}

	// Test data
	private _data = {};
	get data() { return this._data; }
	set data(data: {}) {
		this._data = data;
	}
}
