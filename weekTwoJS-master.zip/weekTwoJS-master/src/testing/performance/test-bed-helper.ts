import {
	getTestBed,
	TestBed
} from '@angular/core/testing';

export function configureTestSuite(testBedConfigFn?: () => void) {
	const testBedRef = getTestBed();
	const originalResetModuleFn = TestBed.resetTestingModule;

	beforeAll(() => {
		TestBed.resetTestingModule();
		TestBed.resetTestingModule = () => TestBed;
	});

	if (testBedConfigFn) {
		beforeAll((done) => (async () => {
			testBedConfigFn();
			await TestBed.compileComponents();
		})().then(done).catch(done.fail));
	}

	afterEach(() => {
		testBedRef['_activeFixtures'].forEach((fixture) => fixture.destroy());
		testBedRef['_instantiated'] = false;
	});

	afterAll(() => {
		TestBed.resetTestingModule = originalResetModuleFn;
		TestBed.resetTestingModule();
	});
}
