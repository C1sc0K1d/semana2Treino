# Angular Test Performance Example

Below is an example of how to improve Angular test performance. 
Angular 9 is supposed to implement similar changes to this, in the meantime though this method can also be used.


First, make a testbed helper function that should help to improve angular test performance by preventing the TestBed from completely recompiling itself on every test run. - [Link To Testbed Helper](https://github.ford.com/WaMCOE/frf-starter/blob/51-angular-test-performance/src/testing/performance/test-bed-helper.ts)

We then implement this testbed helper on the .spec files in our project. - [Link To Example Code](https://github.ford.com/WaMCOE/frf-starter/blob/51-angular-test-performance/src/app/app.component.spec.ts)

