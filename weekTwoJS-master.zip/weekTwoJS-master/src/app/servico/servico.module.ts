import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ServicoFormComponent } from './servico-form/servico-form.component';
import { ServicoListaComponent } from './servico-lista/servico-lista.component';
import { ServicoComponent } from './servico.component';
import { ServicoNavComponent } from '../nav-bars/servico-nav/servico-nav.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule
  ], 
  exports: [
    FormsModule
  ]
})
export class ServicoModule { }
