import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ServicoService } from 'src/app/service/servico.service';
import { ServicoBusca } from './servicoBusca';

@Component({
  selector: 'servico-lista',
  templateUrl: './servico-lista.component.html',
  styleUrls: ['./servico-lista.component.scss']
})
export class ServicoListaComponent implements OnInit {

  nome: string;
  mes: number;
  meses: number[] = [];
  lista: ServicoBusca[];
  message: string;

  constructor(
    private service: ServicoService,
    private router: Router
  ) {
    for (let index = 1; index < 13; index++) {
      this.meses.push(index); 
    }
   }

  ngOnInit() {
  }

  consultar(){
    this.service
      .buscar(this.nome, this.mes)
      .subscribe(respose => {
        this.lista = respose;
        if(this.lista.length <= 0){
          this.message = "Nenhum registro encontrado."
        }else{
          this.message = '';
        }
      });
  }

  cadastrar(){
    this.router.navigate(["/servico/cadastrar"]);
  }

}
