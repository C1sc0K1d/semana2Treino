import { Cliente } from "src/app/models/cliente";

export class ServicoBusca{
    descricao: string;

    valor: number;

    data: string;

    cliente: Cliente;
}