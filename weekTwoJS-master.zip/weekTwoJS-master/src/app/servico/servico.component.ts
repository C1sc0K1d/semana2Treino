import { Component, OnInit } from '@angular/core';
import { ServicoNavComponent } from '../nav-bars/servico-nav/servico-nav.component';

@Component({
  selector: 'servico',
  templateUrl: './servico.component.html',
  styleUrls: ['./servico.component.scss']
})
export class ServicoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
