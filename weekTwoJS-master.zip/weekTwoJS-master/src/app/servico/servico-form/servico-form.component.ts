import { Component, OnInit, Inject } from '@angular/core';
import { DatePipe, DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';


import { ClientesService } from 'src/app/service/clientes.service';
import { Cliente } from 'src/app/models/cliente';
import { ServicoService } from 'src/app/service/servico.service';
import { Servico } from '../../models/servico';


@Component({
  selector: 'servico-form',
  templateUrl: './servico-form.component.html',
  styleUrls: ['./servico-form.component.scss']
})
export class ServicoFormComponent implements OnInit {

  clientes: Cliente[] = [];
  servico: Servico;
  sucess: boolean = false;
  errors: String[] = [];

  constructor(
    private clientesService: ClientesService,
    private service: ServicoService,
    @Inject(DOCUMENT) private _document: Document,
    private router: Router
  ) {
    this.servico = new Servico();
   }

  ngOnInit() {
    this.clientesService
      .getClientes()
      .subscribe( response => this.clientes = response )
  }

  consulta(){
    this.router.navigate(["/servico/lista"]);
  }

  onSubmit(){
    this.servico.data = new DatePipe('en-US').transform(this.servico.data, 'dd/MM/yyyy')
    this.service
      .salvar(this.servico)
      .subscribe( response => {
        this.sucess = true;
        this.errors = [];
  
        (async () => { 
          this.sucess = true;
          this.errors = [];
         
          await delay(1500);

          this.sucess = false;
  
      })();
  
      this.servico = new Servico();
      //this._document.defaultView.location.reload();    

      }, errorResponse => {

        this.errors = [];

        errorResponse.error.error.dataErrors.forEach(erro => {
          this.errors.push(erro.message);
        });
        this.sucess = false;
      } )    
  }
}


function delay(ms: number) {
  return new Promise( resolve => setTimeout(resolve, ms) );
}

