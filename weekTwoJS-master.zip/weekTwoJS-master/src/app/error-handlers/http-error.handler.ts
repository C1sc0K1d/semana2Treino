import {Injectable, ErrorHandler} from '@angular/core';
import {HttpErrorResponse} from '@angular/common/http';
import {
	Message,
	MessageService
} from 'primeng/api';
import {EMPTY} from 'rxjs';

/** Error handler class to assist with cleaning up repeated and consistent HTTP error handling */
@Injectable({
	providedIn: 'root'
})
export class HttpErrorHandler implements ErrorHandler {

	/**
	 * Creates an instance of the HttpErrorHandler
	 * @param messageService an instance of the PrimeNG MessageService
	 */
	constructor(private messageService: MessageService) {
	}

	/**
	 * takes in the errorResponse and errorMessage and uses them to handle the error appropriately.
	 * @param errorResponse the HttpErrorResponse object
	 * @param errorMessage optionally, the Message object for the error
	 * @returns an empty Observable
	 */
	handleError(errorResponse: HttpErrorResponse, errorMessage?: Message) {
		if (errorResponse.error instanceof ErrorEvent) {
			console.error('An error occurred:', errorResponse.error.message);
		} else {
			console.error(
				`Backend returned code ${errorResponse.status}, ` +
				`body was: ${errorResponse.error}`);
		}

		if (errorMessage) {
			this.messageService.add(errorMessage);
		}

		console.error('An Error Has Occurred:', errorResponse);
		return EMPTY;
	}
}
