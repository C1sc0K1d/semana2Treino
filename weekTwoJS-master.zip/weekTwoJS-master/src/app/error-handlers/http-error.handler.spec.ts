import {TestBed} from '@angular/core/testing';

import {HttpErrorHandler} from './http-error.handler';
import {
	HttpClient,
	HttpErrorResponse
} from '@angular/common/http';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import {Data} from '@angular/router';
import {MessageService} from 'primeng/api';
import {MockMessageService} from 'src/testing/primeng-stubs';

describe('HttpErrorHandlerService', () => {
	let httpErrorHandler: HttpErrorHandler;
	let httpClient: HttpClient;
	let httpTestingController: HttpTestingController;
	let service: HttpErrorHandler;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpClientTestingModule],
			providers: [HttpErrorHandler,
				{provide: MessageService, useClass: MockMessageService}
			]
		});
		httpErrorHandler = TestBed.get(HttpErrorHandler);
		httpClient = TestBed.get(HttpClient);
		httpTestingController = TestBed.get(HttpTestingController);
		service = TestBed.get(HttpErrorHandler);
	});

	it('should be created', () => {
		expect(service).toBeTruthy();
	});

	describe('handleError()', () => {
		it('should handle server error and console.error() to log and displayMessage', (done) => {
			const testUrl = 'someurl';
			const errorMessage = 'deliberate 500 error';
			spyOn(console, 'error');

			httpClient.get<Data[]>(testUrl).subscribe(() => fail('should have failed with the 500 error'),
				(serverError: HttpErrorResponse) => {
					expect(serverError.status).toEqual(500, 'status');
					expect(serverError.error).toEqual(errorMessage, 'message');

					const displayMessage = {
						severity: 'error',
						summary: 'Server Error',
						detail: 'A Server Error Occurred, Please try again'
					};

					httpErrorHandler.handleError(serverError, displayMessage).subscribe((handledError) => {
							// deliberately nothing here because we are testing the failure case
						},
						(thrownError) => {
							// returning Empty observable immediately goes to complete block
						},
						() => {
							expect(console.error).toHaveBeenCalledWith('Backend returned code ' + serverError.status + ', body was: ' + serverError.error);
							expect(service['messageService'].add).toHaveBeenCalledWith(displayMessage);
							expect(console.error).toHaveBeenCalledWith('An Error Has Occurred:', serverError);
							done();
						});
				}
			);
			const req = httpTestingController.expectOne(testUrl);
			req.flush(errorMessage, {status: 500, statusText: 'Internal Server Error'});
		});
		it('should handle client/network error and console.error() to log', (done) => {
			const errorEvent = new ErrorEvent('uh oh pskettios', {
				error: new Error('HALP'),
				message: 'Client error message'
			});
			const httpErrorEvent = new HttpErrorResponse({error: errorEvent});
			spyOn(console, 'error');

			const displayMessage = {
				severity: 'error',
				summary: 'Client Error',
				detail: 'A Client Error Occurred, Please try again'
			};

			httpErrorHandler.handleError(httpErrorEvent, displayMessage).subscribe((handledError) => {
					// deliberately nothing here because we are testing the failure case
				},
				(thrownError) => {
					// returning Empty observable immediately goes to complete block
				},
				() => {
					expect(console.error).toHaveBeenCalledWith('An error occurred:', errorEvent.message);
					expect(service['messageService'].add).toHaveBeenCalledWith(displayMessage);
					expect(console.error).toHaveBeenCalledWith('An Error Has Occurred:', httpErrorEvent);
					done();
				});
		});

		it('should not display message if no message is passed in', (done) => {
			const errorEvent = new ErrorEvent('uh oh pskettios', {
				error: new Error('HALP'),
				message: 'Client error message'
			});
			const httpErrorEvent = new HttpErrorResponse({error: errorEvent});
			spyOn(console, 'error');

			httpErrorHandler.handleError(httpErrorEvent).subscribe((handledError) => {
					// deliberately nothing here because we are testing the failure case
				},
				(error) => {
					// returning Empty observable immediately goes to complete block
				},
				() => {
					expect(console.error).toHaveBeenCalledWith('An error occurred:', errorEvent.message);
					expect(service['messageService'].add).not.toHaveBeenCalled();
					expect(console.error).toHaveBeenCalledWith('An Error Has Occurred:', httpErrorEvent);
					done();
				});
		});
	});

});
