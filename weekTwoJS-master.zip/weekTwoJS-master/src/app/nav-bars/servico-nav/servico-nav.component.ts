import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api'

@Component({
  selector: 'servico-nav',
  templateUrl: './servico-nav.component.html',
  styleUrls: ['./servico-nav.component.scss']
})
export class ServicoNavComponent {

  /** Array of PrimeNG MenuItems that are used to populate the p-menubar */
	navServicoMenuItems: MenuItem[];
	/** whether or not the sidebar is open or not */
	sidebarServicoVisible: boolean;
	/** toggles visibility of sidebar to true */
	showSidebar = () => { this.sidebarServicoVisible = true; };
	/** toggles visibility of sidebar to false */
	hideSidebar = () => { this.sidebarServicoVisible = false; };

	/** Create a nav component and populate with necessary MenuItems (static data) */
	constructor() {
		this.navServicoMenuItems = [
			{
				label: 'Cadastro',
				routerLink: '/servico/cadastrar',
				command: this.hideSidebar
			},
			{
				label: 'Serviços',
				routerLink: '/servico/lista',
				command: this.hideSidebar
			}
		];
	}

}
