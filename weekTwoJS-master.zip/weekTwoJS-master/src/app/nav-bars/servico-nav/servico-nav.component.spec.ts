import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicoNavComponent } from './servico-nav.component';

describe('ServicoNavComponent', () => {
  let component: ServicoNavComponent;
  let fixture: ComponentFixture<ServicoNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicoNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicoNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
