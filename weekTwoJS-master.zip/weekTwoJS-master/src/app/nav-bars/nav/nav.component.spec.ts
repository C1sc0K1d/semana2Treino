import {ComponentFixture, TestBed} from '@angular/core/testing';
import {NavComponent} from './nav.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('NavComponent', () => {
	let fixture: ComponentFixture<NavComponent>;
	let componentInstance;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [NavComponent],
			schemas: [NO_ERRORS_SCHEMA]
		}).compileComponents();

		fixture = TestBed.createComponent(NavComponent);
		componentInstance = fixture.componentInstance;
	});
	describe('tests:', () => {
		beforeEach(() => {
			fixture.detectChanges();
		});

		it('should create', () => {
			expect(fixture).not.toBeNull();
		});
		it('should render menu items', () => {
			expect(fixture.componentInstance.navMenuItems.length).toEqual(1);
			expect(fixture.componentInstance.navMenuItems[0].label).toEqual('Example Page');
			expect(fixture.componentInstance.navMenuItems[0].routerLink).toEqual('/example-page');
			expect(fixture.componentInstance.navMenuItems[0].command).toEqual(componentInstance.hideSidebar);
		});

		describe('showSidebar() and hideSidebar() : ', () => {
			it('set sidebarVisible to true when showSidebar is called', () => {
				componentInstance.sidebarVisible = false;
				componentInstance.showSidebar();
				expect(componentInstance.sidebarVisible).toEqual(true);
			});
			it('set sidebarVisible to false when hideSidebar is called', () => {
				componentInstance.sidebarVisible = true;
				componentInstance.hideSidebar();
				expect(componentInstance.sidebarVisible).toEqual(false);
			});
		});
	});
});
