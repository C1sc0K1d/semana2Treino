import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api'

@Component({
  selector: 'cliente-nav',
  templateUrl: './cliente-nav.component.html',
  styleUrls: ['./cliente-nav.component.scss']
})
export class ClienteNavComponent {

  /** Array of PrimeNG MenuItems that are used to populate the p-menubar */
	navClienteMenuItems: MenuItem[];
	/** whether or not the sidebar is open or not */
	sidebarClientesVisible: boolean;
	/** toggles visibility of sidebar to true */
	showSidebar = () => { this.sidebarClientesVisible = true; };
	/** toggles visibility of sidebar to false */
	hideSidebar = () => { this.sidebarClientesVisible = false; };

	/** Create a nav component and populate with necessary MenuItems (static data) */
	constructor() {
		this.navClienteMenuItems = [
			{
				label: 'Cadastrar',
				routerLink: '/clientes/salvar',
				command: this.hideSidebar
			},
			{
				label: 'Alterar',
				routerLink: '/clientes/lista',
				command: this.hideSidebar
			}
		];
	}
}
