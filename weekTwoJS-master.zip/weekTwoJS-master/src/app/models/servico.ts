export class Servico {

    idCliente: number;

    preco: string;

    descricao: string;

    data: string;

}