export class Cliente {
    id: number;
    nome: string;
    cpf: string;
    dataCadastro: string;
}