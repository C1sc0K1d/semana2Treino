import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { AppComponent } from './app.component';
import { NavComponent } from './nav-bars/nav/nav.component';
import { ButtonModule } from 'primeng/button';
import { MenubarModule } from 'primeng/menubar';
import { PanelMenuModule } from 'primeng/panelmenu';
import { SidebarModule } from 'primeng/sidebar';
import { MessageService } from 'primeng/components/common/messageservice';
import { AppRoutingModule } from './app-routing.module';
import { ExamplePageComponent } from './example-page/example-page.component';
import { ToastModule } from 'primeng/toast';
import { NotFoundComponent } from './not-found/not-found.component';
import { ClientesFormComponent } from './clientes/clientes-form/clientes-form.component';
import { TemplateModule } from "./template/template.module";
import { ClientesService } from "./service/clientes.service";
import { ClienteNavComponent } from './nav-bars/cliente-nav/cliente-nav.component';
import { ClientesComponent } from "./clientes/clientes.component";
import { ClientesListComponent } from './clientes/clientes-list/clientes-list.component';
import { ClientesEditComponent } from './clientes/clientes-edit/clientes-edit.component';
import { ServicoFormComponent } from './servico/servico-form/servico-form.component';
import { ServicoListaComponent } from './servico/servico-lista/servico-lista.component';
import { ServicoNavComponent } from './nav-bars/servico-nav/servico-nav.component';
import { ServicoComponent } from './servico/servico.component';
import { ServicoService } from './service/servico.service';
import { AuthGuardService, Env, HttpRequestInterceptor, NgADFSModule, UrlConsumerService, UserIdService } from '@sade/ng-adfs';


@NgModule({
	declarations: [
		AppComponent,
		NavComponent,
		ExamplePageComponent,
		NotFoundComponent,
		ClientesComponent,
		ClientesFormComponent,
		ClientesListComponent,
		ClientesEditComponent,
		ClienteNavComponent,
		ServicoFormComponent, 
    	ServicoListaComponent, 
		ServicoComponent,
		ServicoNavComponent
	],
	imports: [
		BrowserModule,
		HttpClientModule,
		BrowserAnimationsModule,
		RouterModule,
		AppRoutingModule,
		ButtonModule,
		MenubarModule,
		PanelMenuModule,
		NgADFSModule.forRoot({
			clientId: "urn:clientes:clientid:web_clientes:qa",
			environment: Env.QA, // Set the ADFS environment what you are using, with 'Env' enum
			resourceUri: "urn:clientes:resource:web_clientes:qa"
		}),
		SidebarModule,
		ToastModule,
		TemplateModule,
		FormsModule
	],
	providers: [
		{
			provide: HTTP_INTERCEPTORS,
			useClass: HttpRequestInterceptor,
			multi: true
		},
		UserIdService, 
		AuthGuardService, 
		UrlConsumerService,
		MessageService,
		ClientesService,
		ServicoService
	],
	bootstrap: [AppComponent]
})
export class AppModule {
}
