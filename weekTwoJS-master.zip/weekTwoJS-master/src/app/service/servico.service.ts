import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

import { Servico } from '../models/servico';
import { environment } from '../../environments/environment'
import { ServicoBusca } from '../servico/servico-lista/servicoBusca';


@Injectable({
  providedIn: 'root'
})
export class ServicoService {

  apiUrl: string = environment.apiUrl + "/api/servicos";

  constructor( private http: HttpClient ) {  }

  salvar(servico: Servico): Observable<Servico>{
    return this.http.post<Servico>(`${this.apiUrl}`, servico);
  }

  buscar(nome: string, mes: number): Observable<ServicoBusca[]> {

    const httpParams = new HttpParams()
      .set("nome", nome)
      .set("mes", mes ? mes.toString() : '');
    
    const url= this.apiUrl + "?" + httpParams.toString();
    console.log(url);
    
    return this.http.get<any>(url).pipe(map((data:any) => data.result.servicos as ServicoBusca[]));
  }

}
