import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

import { Cliente } from '../models/cliente';
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class ClientesService {

  apiUrl: string = environment.apiUrl + "/api/clientes";

  constructor( private http: HttpClient ) { 

  }

  salvar( cliente: Cliente ) : Observable<Cliente> {
    return this.http.post<Cliente>(`${this.apiUrl}`, cliente);
  }

  atualizar( cliente: Cliente ) : Observable<any> {
    return this.http.put<Cliente>(`${this.apiUrl}/${cliente.id}`, cliente);
  }

  getClientById(id: number): Observable<Cliente>{
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(map((data:any) => data.result.cliente as Cliente));
  }

  getClientes() : Observable<Cliente[]> {
    return this.http.get<Cliente[]>(`${this.apiUrl}`).pipe(map((data:any) => data.result.clientes as Cliente[]));
  }

  deletar(cliente: Cliente): Observable<any>{
    return this.http.delete<any>(`${this.apiUrl}/${cliente.id}`);
  }
 
}
