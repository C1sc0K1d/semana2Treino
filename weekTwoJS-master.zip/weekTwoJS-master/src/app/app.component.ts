import {Component, VERSION} from '@angular/core';
import {environment} from '../environments/environment';

/** Class for the app component that is bootstrapped to run the application
 */
@Component({
	selector: 'body',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	/** the Angular version */
	version = "1.0.0";
	/** whether we are production or not */
	envProd = environment.production;
}
