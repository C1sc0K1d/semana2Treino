import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';


import { Cliente } from "../../models/cliente";
import { ClientesService } from "../../service/clientes.service";


@Component({
  selector: 'clientes-form',
  templateUrl: './clientes-form.component.html',
  styleUrls: ['./clientes-form.component.scss']
})

export class ClientesFormComponent implements OnInit {

  cliente: Cliente;
  sucess: boolean = false;
  errors: String[] = [];

  constructor( 
    private service: ClientesService,
    @Inject(DOCUMENT) private _document: Document,
    private router: Router
    ) {
    this.cliente = new Cliente();
   }

  ngOnInit() {}

  onSubmit(){
    this.service.salvar(this.cliente).subscribe( response => {
      this.sucess = true;
      this.errors = [];

      (async () => { 
        this.sucess = true;
        this.errors = [];
       
        await delay(1500);

        this.sucess = false;

    })();

    this.cliente = new Cliente();
    
     
    }, errorResponse => {
      this.errors = [];
      errorResponse.error.error.dataErrors.forEach(erro => {
        this.errors.push(erro.message);
      });
      this.sucess = false;
    } )
  }

  listaClientes(){
    this.router.navigate(["/clientes/lista"])
  }

}

function delay(ms: number) {
  return new Promise( resolve => setTimeout(resolve, ms) );
}
