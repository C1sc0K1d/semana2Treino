import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Cliente } from "../../models/cliente";
import { ClientesService } from "../../service/clientes.service";


@Component({
  selector: 'clientes-edit',
  templateUrl: './clientes-edit.component.html',
  styleUrls: ['./clientes-edit.component.scss']
})
export class ClientesEditComponent implements OnInit {

  cliente: Cliente;
  sucess: boolean = false;
  errors: String[] = [];
  id: number;

  constructor( 
    private service: ClientesService,
    private activatedRoute: ActivatedRoute,
    private router: Router
    ) { 
    this.cliente = new Cliente();
  }

  ngOnInit() {
    let parms = this.activatedRoute.params;
    parms.subscribe( urlParms => {
      this.id = urlParms['id']
      this.service.getClientById(this.id)
    .subscribe( response => this.cliente = response, errorResponse => this.cliente = new Cliente())
    
    } )
  }

  onSubmit(){
    this.service.atualizar(this.cliente).subscribe( response => {
      this.sucess = true;
      this.errors = [];
    }, errorResponse => {
      errorResponse.error.error.dataErrors.forEach(erro => {
        this.errors.push(erro.message);
      });
      console.log(errorResponse);
      
      this.sucess = false;
    } )
  }

  voltar(){
    this.router.navigate(["/clientes/lista"])
  }

}
