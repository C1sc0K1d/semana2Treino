import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.scss']
})
export class ClientesComponent implements OnInit {

  nome: string;
  clientes: Cliente[];

  constructor() { 
      }

  ngOnInit() {
  }

}

class Cliente {
  constructor(public nome: string, public idade: number){}
}
