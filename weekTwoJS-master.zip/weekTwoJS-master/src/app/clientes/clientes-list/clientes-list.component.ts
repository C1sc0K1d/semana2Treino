import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { ClientesService } from 'src/app/service/clientes.service';
import { Cliente } from '../../models/cliente';

@Component({
  selector: 'clientes-list',
  templateUrl: './clientes-list.component.html',
  styleUrls: ['./clientes-list.component.scss']
})
export class ClientesListComponent implements OnInit {

  clientes: Cliente[] = [];
  clienteSelecionado: Cliente;
  mensagemSucesso: string;
  mensagemErro: string;

  constructor( 
    private service: ClientesService, 
    private router: Router ) {}

  ngOnInit() {
    this.service
    .getClientes()
    .subscribe( response => this.clientes = response )
  }

  novoCadastro(){
    this.router.navigate(["/clientes/salvar"])
  }

  preparaDelecao(cliente: Cliente){
    this.clienteSelecionado = cliente
  }

  deletarCliente(){
    this.service.deletar(this.clienteSelecionado)
    .subscribe( 
      response => {
        this.mensagemSucesso = "Cliente deletado"
        this.ngOnInit()
      },
      erro => this.mensagemErro = "Erro ao deletar cliente"
      )

    
  }

}
