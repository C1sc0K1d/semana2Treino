import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ExamplePageComponent} from './example-page/example-page.component';
import {NotFoundComponent} from './not-found/not-found.component';

import { ClientesFormComponent } from './clientes/clientes-form/clientes-form.component';
import { ClientesComponent } from './clientes/clientes.component'
import { ClientesListComponent } from './clientes/clientes-list/clientes-list.component';
import { ClientesEditComponent } from './clientes/clientes-edit/clientes-edit.component';

import { ServicoFormComponent } from './servico/servico-form/servico-form.component';
import { ServicoListaComponent } from './servico/servico-lista/servico-lista.component';
import { ServicoComponent } from './servico/servico.component';
import { AuthGuardService, UrlConsumerService } from '@sade/ng-adfs';

const routes: Routes = [
	{ 
		path: 'main', 
		component: ExamplePageComponent,
		canActivate: [AuthGuardService]
 	},
	{ 
		path: "clientes",	
		component: ClientesComponent,
		canActivate: [AuthGuardService]
	 },
	{ 
		path: "clientes/salvar",
		component: ClientesFormComponent,
		canActivate: [AuthGuardService]
	},
	{ 
		path: "clientes/lista",	
		component: ClientesListComponent,
		canActivate: [AuthGuardService]
	},
	{ 
		path: "clientes/editar/:id",	
		component: ClientesEditComponent,
		canActivate: [AuthGuardService]	
	},
	{ 
		path: "servico",
		component: ServicoComponent,
		canActivate: [AuthGuardService]
	 },
	{
		path: "servico/cadastrar",
		component: ServicoFormComponent,
		canActivate: [AuthGuardService]
	},
	{
		path: "servico/lista",
		component: ServicoListaComponent,
		canActivate: [AuthGuardService]
	},
	{
		path: 'access_token',
		component: ExamplePageComponent,
		canActivate: [UrlConsumerService]
	},
	{ path: '', redirectTo: '/main', pathMatch: 'full' },
	{ path: '404', component: NotFoundComponent },
	{ path: '**', redirectTo: '/404' }
];

@NgModule({
	imports: [RouterModule.forRoot(routes, {useHash: true})],
	exports: [RouterModule]
})
export class AppRoutingModule {}
