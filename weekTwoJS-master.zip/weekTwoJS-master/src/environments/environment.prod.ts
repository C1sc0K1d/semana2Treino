/**This file contains a constant object that has properties that are necessary
 * for the build found in the `production` configuration in `angular.json`.
 */
export const environment = {
	production: true,
	apiUrl: 'https://eng-weektwo-dev.apps.pp01i.edc1.cf.ford.com'
	// include production api base url string as a property here
};
