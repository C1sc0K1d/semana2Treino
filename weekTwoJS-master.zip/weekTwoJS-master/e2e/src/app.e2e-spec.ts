import {AppComponentPage} from './app.pageobject';
import { browser, logging } from 'protractor';

describe('App Component Page', () => {
	let appComponentPage: AppComponentPage;

	beforeAll(() => {
		appComponentPage = new AppComponentPage();
		appComponentPage.load();
	});

	describe('Header', () => {
		it('should display the app name', () => {
			expect(appComponentPage.getApplicationTitle()).toEqual('Ford Starter WebApp');
		});
	});

	describe('Footer', () => {
		it('should display the angular version', () => {
			expect(appComponentPage.getAngularVersion()).toEqual('Version: 8.2.13');
		});
	});

	afterEach(async () => {
		// Assert that there are no errors emitted from the browser
		const logs = await browser.manage().logs().get(logging.Type.BROWSER);
		expect(logs).not.toContain(jasmine.objectContaining({
			level: logging.Level.SEVERE,
		} as logging.Entry));
	});
});
