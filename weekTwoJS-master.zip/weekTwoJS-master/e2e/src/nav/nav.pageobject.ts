import {browser, element, by} from 'protractor';

export class NavPage {
	load() {
		return browser.get('./');
	}

	getNavigationLinks() {
		return element.all(by.css('.ui-menubar .ui-menuitem-link'));
	}
}
