const fs = require('fs');
const os = require('os');
const https = require('https');
const osType = os.platform();
const path = require('path');
const exec = require('child_process').exec;
const spawn = require('child_process').spawn;

//helper function for handling HTTP get
//based on this stackoverflow post https://stackoverflow.com/a/22907134
const downloadFile = function(url, dest, cb) {
	const file = fs.createWriteStream(dest);
	https.get(url, function(response) {
		response.pipe(file);
		file.on('finish', function() {
			console.log('downloaded ', url, 'to ', dest, ' successfully');
			file.close(cb);
		});
	}).on('error', function(err) {
		fs.unlink(dest);
		if (cb) cb(err.message);
	});
};

const nexusUrl = "https://www.nexus.ford.com/repository/wamcoe_raw_private_repository/";
const protractorSeleniumLocation = "node_modules/protractor/selenium";
//write stream bails out if the folder doesn't exist. make it first.
if(!fs.existsSync(protractorSeleniumLocation)) {
	fs.mkdirSync(protractorSeleniumLocation);
}

const chromedriverVersion = '83.0.4103.39';
let chromedriverFileName = '';
const geckodriverVersion = '0.26.0';
let geckodriverFileName = '';

if(osType === 'win32') {
	chromedriverFileName = 'chromedriver_win32.zip';
	geckodriverFileName = 'geckodriver-v' + geckodriverVersion + '-win64.zip';
}
else if(osType === 'darwin') {
	chromedriverFileName = 'chromedriver_mac64.tar';
	geckodriverFileName = 'geckodriver-v' + geckodriverVersion + '-macos.tar';
}
else {
	chromedriverFileName = 'chromedriver_linux64.tar';
	geckodriverFileName = 'geckodriver-v' + geckodriverVersion + '-linux64.tar';
}

const browserDriverUnzip = function(driverFileName){
	//no unzip support in vanilla node. default back to the command line
	if(osType === 'win32') {
		//use 7zip on windows boxes
		const unzip = spawn('7z', ['x', driverFileName, '-aoa', '&&', 'del', driverFileName], {cwd: protractorSeleniumLocation, shell: true});

		/*unzip.stdout.on('data', function(data) {
            console.log('Chrome Driver stdout: ', data);
        });*/

		unzip.stderr.on('data', function(data) {
			console.log(driverFileName, ' stderr: ', data);
		});

		unzip.on('close', function(code) {
			console.log(driverFileName, ' unzip process exited with code ', code);
		});
	}
	else {
		//use gunzip on unix
		const gunzip = spawn('gunzip', ['-fN', driverFileName + '.gz'], {cwd: protractorSeleniumLocation});

		gunzip.stdout.on('data', function(data) {
			fs.writeFile(driverFileName, data, function(err) {
			});
		});

		gunzip.stderr.on('data', function(data) {
			console.log('gunzip stderr: ', data);
		});

		gunzip.on('close', function(code) {
			if (code !== 0) {
				console.log('gunzip process exited with code ', code);
			}else{
				console.log(driverFileName, ' gunzip completed');
			}

			const tar = spawn('tar', ['xopf', driverFileName], {cwd: protractorSeleniumLocation});

			// tar.stdout.on('data', function(data) {
			// 	console.log('tar stdout: ', data);
			// });

			tar.stderr.on('data', function(data) {
				console.log('tar stderr: ', data);
			});

			tar.on('close', function(code) {
				if (code !== 0) {
					console.log('tar process exited with code ', code);
				}else{
					console.log(driverFileName, ' tar process completed');
				}
			});
		});
	}
};

if(osType === 'win32') {
	downloadFile(nexusUrl + "chromedriver/" + chromedriverVersion + "/" + chromedriverFileName,
		path.join(protractorSeleniumLocation, chromedriverFileName), browserDriverUnzip.bind(this, chromedriverFileName));
	downloadFile(nexusUrl + "geckodriver/v" + geckodriverVersion + "/" + geckodriverFileName,
		path.join(protractorSeleniumLocation, geckodriverFileName), browserDriverUnzip.bind(this, geckodriverFileName));
} else {
	downloadFile(nexusUrl + "chromedriver/" + chromedriverVersion + "/" + chromedriverFileName + ".gz",
		path.join(protractorSeleniumLocation, chromedriverFileName + ".gz"), browserDriverUnzip.bind(this, chromedriverFileName));
	downloadFile(nexusUrl + "geckodriver/v" + geckodriverVersion + "/" + geckodriverFileName + ".gz",
		path.join(protractorSeleniumLocation, geckodriverFileName + ".gz"), browserDriverUnzip.bind(this, geckodriverFileName));
}
